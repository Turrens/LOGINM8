package com.example.mainapiconnectionsinasyntask;

public class Usuario {
    private String nombre;
    private String fechaNacimiento;
    private String contrasena;

    public Usuario(String nombre, String fechaNacimiento, String contrasena) {
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.contrasena = contrasena;
    }

    public String getNombre() {
        return nombre;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
}