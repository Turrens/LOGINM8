package com.example.mainapiconnectionsinasyntask;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ErroresInicioSesionActivity extends AppCompatActivity {
    private RecyclerView recyclerViewErrores;
    private ErroresAdapter erroresAdapter;
    private List<IntentoFallido> listaErrores;
    private AdmBaseDatosSQLite dbHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_errores_inicio_sesion);

        recyclerViewErrores = findViewById(R.id.recyclerViewErrores);
        recyclerViewErrores.setLayoutManager(new LinearLayoutManager(this));
        listaErrores = new ArrayList<>();
        erroresAdapter = new ErroresAdapter(listaErrores);
        recyclerViewErrores.setAdapter(erroresAdapter);

        dbHelper = new AdmBaseDatosSQLite(this);
        cargarErroresDesdeSQLite();
    }

    private void cargarErroresDesdeSQLite() {
        listaErrores.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM intentos_fallidos", null);

        if (cursor.moveToFirst()) {
            do {
                String usuario = cursor.getString(cursor.getColumnIndex("usuario"));
                String contrasena = cursor.getString(cursor.getColumnIndex("contrasena"));
                String fechaHora = cursor.getString(cursor.getColumnIndex("fecha_hora"));

                listaErrores.add(new IntentoFallido(usuario, contrasena, fechaHora));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        erroresAdapter.notifyDataSetChanged();
    }
}
