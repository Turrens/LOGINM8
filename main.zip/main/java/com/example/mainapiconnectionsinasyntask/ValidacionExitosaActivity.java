package com.example.mainapiconnectionsinasyntask;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class ValidacionExitosaActivity extends AppCompatActivity {
    private RecyclerView recyclerViewUsuarios;
    private UsuarioAdapter usuarioAdapter;
    private List<Usuario> listaUsuarios;
    private ExecutorService executorService;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validacion_exitosa);

        recyclerViewUsuarios = findViewById(R.id.recyclerViewUsuarios);
        recyclerViewUsuarios.setLayoutManager(new LinearLayoutManager(this));
        listaUsuarios = new ArrayList<>();
        usuarioAdapter = new UsuarioAdapter(listaUsuarios);
        recyclerViewUsuarios.setAdapter(usuarioAdapter);

        executorService = Executors.newSingleThreadExecutor();

        // Obtener los usuarios desde el servidor
        obtenerUsuariosDesdeServidor("http://10.0.2.2/consultausuarios.php");
    }

    private void obtenerUsuariosDesdeServidor(String urlString) {
        executorService.execute(() -> {
            String resultado = "";
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();
                resultado = result.toString();

                procesarResultadoServidor(resultado);
            } catch (Exception e) {
                Log.e("ValidacionExitosa", "Error al obtener usuarios", e);
                runOnUiThread(() -> Toast.makeText(ValidacionExitosaActivity.this, "Error al obtener usuarios desde el servidor", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void procesarResultadoServidor(String resultado) {
        runOnUiThread(() -> {
            try {
                // Procesar el XML con DocumentBuilder
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document doc = builder.parse(new InputSource(new StringReader(resultado)));

                // Limpiar la lista de usuarios
                listaUsuarios.clear();

                // Obtener la lista de nodos <usuario>
                NodeList listaNodosUsuarios = doc.getElementsByTagName("usuario");

                // Procesar cada nodo <usuario>
                for (int i = 0; i < listaNodosUsuarios.getLength(); i++) {
                    Element elementoUsuario = (Element) listaNodosUsuarios.item(i);
                    String usuario = elementoUsuario.getElementsByTagName("nombre").item(0).getTextContent();
                    String contrasena = elementoUsuario.getElementsByTagName("contrasena").item(0).getTextContent();
                    String fechaNacimiento = elementoUsuario.getElementsByTagName("fecha_nacimiento").item(0).getTextContent();

                    // Añadir usuario a la lista
                    listaUsuarios.add(new Usuario(usuario, fechaNacimiento,contrasena));
                }

                // Notificar al adaptador que los datos han cambiado
                usuarioAdapter.notifyDataSetChanged();

            } catch (Exception e) {
                Toast.makeText(ValidacionExitosaActivity.this, "Error al procesar los datos del servidor", Toast.LENGTH_SHORT).show();
                Log.e("ValidacionExitosa", "Error al parsear XML", e);
            }
        });
    }
}
