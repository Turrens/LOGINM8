package com.example.mainapiconnectionsinasyntask;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UsuarioAdapter extends RecyclerView.Adapter<UsuarioAdapter.UsuarioViewHolder> {

    private final List<Usuario> usuarios;

    public UsuarioAdapter(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    @NonNull
    @Override
    public UsuarioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_usuario, parent, false);
        return new UsuarioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UsuarioViewHolder holder, int position) {
        Usuario usuario = usuarios.get(position);
        holder.textViewUsuario.setText(usuario.getNombre());
        holder.textViewFechaNacimiento.setText(usuario.getFechaNacimiento());
        holder.textViewContrasena.setText(usuario.getContrasena());  // Mostrar la contraseña
    }

    @Override
    public int getItemCount() {
        return usuarios.size();
    }

    static class UsuarioViewHolder extends RecyclerView.ViewHolder {
        TextView textViewUsuario;
        TextView textViewFechaNacimiento;
        TextView textViewContrasena;

        public UsuarioViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewUsuario = itemView.findViewById(R.id.textViewUsuario);
            textViewFechaNacimiento = itemView.findViewById(R.id.textViewFechaNacimiento);
            textViewContrasena = itemView.findViewById(R.id.textViewContrasena);  // Inicializar el nuevo TextView
        }
    }
}
