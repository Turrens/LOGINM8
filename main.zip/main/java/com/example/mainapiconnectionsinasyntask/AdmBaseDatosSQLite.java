package com.example.mainapiconnectionsinasyntask;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import androidx.annotation.Nullable;

public class AdmBaseDatosSQLite extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "login_attempts.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "intentos_fallidos";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USUARIO = "usuario";
    private static final String COLUMN_CONTRASENA = "contrasena";
    private static final String COLUMN_FECHA_HORA = "fecha_hora";

    public AdmBaseDatosSQLite(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USUARIO + " TEXT, "
                + COLUMN_CONTRASENA + " TEXT, "
                + COLUMN_FECHA_HORA + " DATETIME DEFAULT CURRENT_TIMESTAMP"
                + ");";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Método para insertar un intento fallido
    public void insertarIntentoFallido(String usuario, String contrasena) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USUARIO, usuario);
        values.put(COLUMN_CONTRASENA, contrasena);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Método para obtener todos los intentos fallidos
    public Cursor obtenerIntentosFallidos() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
}

