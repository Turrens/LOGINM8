package com.example.mainapiconnectionsinasyntask;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class UsuarioValidator {
    private final Context context;
    private final AdmBaseDatosSQLite dbHelper;  // Añadir acceso a la base de datos

    // Executor para manejar las tareas en segundo plano
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    public UsuarioValidator(Context context) {
        this.context = context;
        this.dbHelper = new AdmBaseDatosSQLite(context);  // Inicializar la base de datos
    }

    public void validarUsuario(String usuario, String contrasena) {
        // Validaciones previas
        if (usuario.isEmpty() || contrasena.isEmpty()) {
            Toast.makeText(context, "El usuario y la contraseña no pueden estar vacíos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!usuario.matches("^[a-zA-Z0-9]+$")) {
            Toast.makeText(context, "El nombre de usuario solo puede contener letras y números", Toast.LENGTH_SHORT).show();
            return;
        }

        if (contrasena.length() < 4 || contrasena.length() > 8) {
            Toast.makeText(context, "La contraseña debe tener entre 4 y 8 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }

        // Si todas las validaciones pasan, continuar con la conexión al servidor
        executor.execute(() -> {
            String url = "http://10.0.2.2/validacuenta.php"; // Reemplaza con la URL de tu archivo PHP
            String resultado = null;

            try {
                // Crear la conexión HTTP
                URL direccion = new URL(url);
                HttpURLConnection conexion = (HttpURLConnection) direccion.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);

                // Crear los datos del formulario
                String datos = "usuario=" + usuario + "&contrasena=" + contrasena;

                // Escribir los datos del formulario en la solicitud HTTP
                OutputStream salida = conexion.getOutputStream();
                byte[] bytes = datos.getBytes(StandardCharsets.UTF_8);
                salida.write(bytes);
                salida.flush();
                salida.close();

                // Leer la respuesta del servidor
                InputStream entrada = conexion.getInputStream();
                BufferedReader lector = new BufferedReader(new InputStreamReader(entrada));
                StringBuilder respuesta = new StringBuilder();
                String linea;

                while ((linea = lector.readLine()) != null) {
                    respuesta.append(linea);
                }

                // Cerrar la conexión HTTP
                entrada.close();
                conexion.disconnect();

                // Procesar la respuesta del servidor
                resultado = respuesta.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }

            String finalResultado = resultado;
            // Usamos el handler para actualizar la UI en el hilo principal
            handler.post(() -> onPostExecute(finalResultado, usuario, contrasena));
        });
    }

    private void onPostExecute(String resultado, String usuario, String contrasena) {
        if (resultado != null) {
            // Convertir el resultado en un documento XML y obtener el estado
            Document doc = convertirStringToXMLDocument(resultado);
            if (doc != null) {
                NodeList listaItem = doc.getElementsByTagName("respuesta");
                if (listaItem.getLength() > 0) {
                    Element element = (Element) listaItem.item(0);
                    String var_id = element.getElementsByTagName("estado").item(0).getTextContent();

                    // Abrir la nueva actividad en función del resultado de la validación
                    if (var_id.equals("ok") && context instanceof Activity) {
                        Intent intent = new Intent(context, ValidacionExitosaActivity.class);
                        context.startActivity(intent);
                    } else if (var_id.equals("ko")) {
                        Toast.makeText(context, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
                        dbHelper.insertarIntentoFallido(usuario, contrasena);  // Registrar intento fallido
                        if (context instanceof Activity) {
                            Intent intent = new Intent(context, ErroresInicioSesionActivity.class);
                            context.startActivity(intent);
                        }
                    } else {
                        Toast.makeText(context, "Respuesta desconocida del servidor", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, "Error al procesar la respuesta del servidor", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(context, "Error al convertir la respuesta del servidor", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Manejo del caso donde `resultado` es nulo o hubo un error
            Toast.makeText(context, "Error de conexión", Toast.LENGTH_SHORT).show();
        }
    }

    // Método auxiliar para convertir String a XML Document
    private static Document convertirStringToXMLDocument(String xmlString) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            return builder.parse(new InputSource(new StringReader(xmlString)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
