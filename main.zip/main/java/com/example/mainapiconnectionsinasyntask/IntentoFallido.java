package com.example.mainapiconnectionsinasyntask;

public class IntentoFallido {
    private String usuario;
    private String contrasena;
    private String fechaHora;

    public IntentoFallido(String usuario, String contrasena, String fechaHora) {
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.fechaHora = fechaHora;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public String getFechaHora() {
        return fechaHora;
    }
}
