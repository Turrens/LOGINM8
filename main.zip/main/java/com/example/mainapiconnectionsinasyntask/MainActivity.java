package com.example.mainapiconnectionsinasyntask;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.Cursor;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText editTextUsuario;
    private EditText editTextContrasena;
    private Button buttonValidar;
    private AdmBaseDatosSQLite dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializar vistas
        editTextUsuario = findViewById(R.id.editTextUsuario);
        editTextContrasena = findViewById(R.id.editTextContrasena);
        buttonValidar = findViewById(R.id.buttonValidar);

        // Inicializar la base de datos
        dbHelper = new AdmBaseDatosSQLite(this);

        // Configurar el botón
        buttonValidar.setOnClickListener(v -> {
            // Obtener los valores de los campos
            String usuario = editTextUsuario.getText().toString().trim();
            String contrasena = editTextContrasena.getText().toString().trim();

            if (!usuario.isEmpty() && !contrasena.isEmpty()) {
                // Llamar a UsuarioValidator para validar el usuario
                UsuarioValidator validator = new UsuarioValidator(MainActivity.this);
                validator.validarUsuario(usuario, contrasena);
            } else {
                Toast.makeText(this, "Por favor, ingresa usuario y contraseña", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Método simulado para validar el usuario
    private boolean validarUsuario(String usuario, String contrasena) {
        // Aquí puedes implementar la lógica de validación real, como una solicitud a un servidor
        return usuario.equals("testuser") && contrasena.equals("password123");
    }

    // Método para mostrar los intentos fallidos (puedes usarlo en otra actividad)
    private void mostrarIntentosFallidos() {
        Cursor cursor = dbHelper.obtenerIntentosFallidos();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String usuario = cursor.getString(cursor.getColumnIndexOrThrow("usuario"));
                String contrasena = cursor.getString(cursor.getColumnIndexOrThrow("contrasena"));
                String fechaHora = cursor.getString(cursor.getColumnIndexOrThrow("fecha_hora"));
                // Aquí puedes usar estos datos para mostrarlos en un ListView o RecyclerView
            } while (cursor.moveToNext());
        }
        if (cursor != null) {
            cursor.close();
        }
    }
}
