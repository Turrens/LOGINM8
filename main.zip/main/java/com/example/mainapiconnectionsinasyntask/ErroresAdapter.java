package com.example.mainapiconnectionsinasyntask;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ErroresAdapter extends RecyclerView.Adapter<ErroresAdapter.ErroresViewHolder> {

    private final List<IntentoFallido> intentosFallidos;

    public ErroresAdapter(List<IntentoFallido> intentosFallidos) {
        this.intentosFallidos = intentosFallidos;
    }

    @NonNull
    @Override
    public ErroresViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_error, parent, false);
        return new ErroresViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ErroresViewHolder holder, int position) {
        IntentoFallido intento = intentosFallidos.get(position);
        holder.textViewUsuario.setText(intento.getUsuario());
        holder.textViewContrasena.setText(intento.getContrasena());
        holder.textViewFechaHora.setText(intento.getFechaHora());
    }

    @Override
    public int getItemCount() {
        return intentosFallidos.size();
    }

    static class ErroresViewHolder extends RecyclerView.ViewHolder {
        TextView textViewUsuario;
        TextView textViewContrasena;
        TextView textViewFechaHora;

        public ErroresViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewUsuario = itemView.findViewById(R.id.textViewUsuario);
            textViewContrasena = itemView.findViewById(R.id.textViewContrasena);
            textViewFechaHora = itemView.findViewById(R.id.textViewFechaHora);
        }
    }
}
